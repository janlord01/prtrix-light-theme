jQuery(document).ready(function($){
    //Mobile menu
    $("#mobile-button").click(function(){
        if($(this).hasClass('opened')){
            $("#header-achadata .menu").fadeIn("slow"); 
        }else{
            $("#header-achadata .menu").fadeOut("slow"); 
        }
    })
});