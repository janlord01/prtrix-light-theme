<?php
get_header();

$url = get_author_posts_url(get_the_author_meta('ID'));

$fname = get_the_author_meta('first_name');
$lname = get_the_author_meta('last_name');
?>
<main id="main">
    <?php

    if ( have_posts() )
    {
        while ( have_posts() )
        {
            the_post();
            ?>
            <div class="block"><!--here we have the whole content of the page-->
                <div class="page-body">
                    <div class="content-page"><!--The whole content we added-->
                        <?php the_content( );?>
						<p>Escrito por: <a href="<?php echo $url; ?>"><?php echo $fname . ' ' . $lname; ?></a></p>
                    </div>
                </div>
            </div>
            <?php
        } // end while
    } // end if
    ?>
</main>
<?php

get_footer();
