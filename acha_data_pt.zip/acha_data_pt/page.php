<?php
get_header();
?>
<main id="main">
    <?php

    if ( have_posts() )
    {
        while ( have_posts() )
        {
            the_post();
            ?>
            <div class="block"><!--here we have the whole content of the page-->
                <div class="page-body">
                    <div class="content-page"><!--The whole content we added-->
                        <?php the_content( ); ?>
                    </div>
                </div>
            </div>
            <?php
        } // end while
    } // end if
    ?>
</main>
<?php

get_footer();
