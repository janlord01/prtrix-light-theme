<?php get_header(); ?>

<div id="content" class="narrowcolumn">

<!-- This sets the $curauth variable -->

    <?php
    $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
    /* echo '<pre>';
    var_dump($curauth);
    echo '</pre>'; */
    ?>
	<div id="author-img"><img src="<?php echo !empty($author_img = get_option('wht_author_img')) ? $author_img . '" width="250" height="250"' : get_avatar_url($curauth->ID) . '" width="96" height="96"'; ?> alt="Meghan O'Neal author picture"></div>
    <h1>Sobre la autora: <?php echo $curauth->nickname; ?></h1>
    <dl>
        <dt>Website</dt>
        <dd><a rel="nofollow noreferrer noopener" target="_blank" href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->user_url; ?></a></dd>
        <dt>LinkedIn:</dt>
        <dd><a rel="nofollow noreferrer noopener" target="_blank" href="<?php echo nl2br(get_the_author_meta('linkedin')); ?>">LinkedIn</a></dd>
		<dt>Acerca de:</dt>
        <dd><?php echo $curauth->user_description; ?></dd>
    </dl>

    <h2>Artículos escritos por <?php echo $curauth->nickname; ?>:</h2>

    <ul>
<!-- The Loop -->

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <li>
            <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>">
            <?php the_title(); ?></a>
            <span><?php the_time('d M Y'); ?></span>
        </li>

    <?php endwhile; else: ?>
        <p><?php _e('No posts by this author.'); ?></p>

    <?php endif; ?>

<!-- End Loop -->

    </ul>
</div>
<?php get_footer(); ?>