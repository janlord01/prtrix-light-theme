<?php //Header("Cache-Control: max-age=3000, must-revalidate"); ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body id="body-achadata" <?php body_class(); ?>>

    <header id="header-achadata" class="navbar navbar-default" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <?php
                    if(has_custom_logo()){
                        the_custom_logo();
                    }else{
                        ?>

                <a class="navbar-brand" href="<?php  echo home_url(); ?>"><img width="250" height="65"
                        src="<?php echo get_template_directory_uri() ?>/images/logo-wholesale-body-jewellery.png"
                        alt="wholesale-body-jewelry-logo" /></a>

                <!-- Disabled by Garry in May 27, 2024, replaced with code above -->
                <!-- <a class="navbar-brand" href="<?php  echo home_url(); ?>"><img width="65" height="65" src="https://achadata.com/wp-content/uploads/2020/11/logo-achadata-naranja.png" alt="logo achadata" /></a> -->
                <?php
                    }
                    ?>

                <button id="mobile-button"
                    onclick="this.classList.toggle('opened');this.setAttribute('aria-expanded', this.classList.contains('opened'))"
                    aria-label="Main Menu">
                    <svg width="40" height="40" viewBox="0 0 100 100">
                        <path class="line line1"
                            d="M 20,29.000046 H 80.000231 C 80.000231,29.000046 94.498839,28.817352 94.532987,66.711331 94.543142,77.980673 90.966081,81.670246 85.259173,81.668997 79.552261,81.667751 75.000211,74.999942 75.000211,74.999942 L 25.000021,25.000058" />
                        <path class="line line2" d="M 20,50 H 80" />
                        <path class="line line3"
                            d="M 20,70.999954 H 80.000231 C 80.000231,70.999954 94.498839,71.182648 94.532987,33.288669 94.543142,22.019327 90.966081,18.329754 85.259173,18.331003 79.552261,18.332249 75.000211,25.000058 75.000211,25.000058 L 25.000021,74.999942" />
                    </svg>
                </button>

            </div>

            <?php
        wp_nav_menu( array(
            'menu'   => 'primary',
            'container_class' => 'menu'
            )
        );
        ?>
        </div>
    </header>
    <div id="header-top-text">
        <div id="top-text-ani">
            <div> <span>✓</span><span>Free Domestic Shipping for Orders >$150</span></div>
            <div> <span>✓</span><span>30-Day Money-Back Guarantee</span></div>
            <div> <span>✓</span><span>No Minimum Order Quantity for Products</span></div>
            <div> <span>✓</span><span>10,000+ products in stock</span></div>
        </div>
    </div>
    <?php
do_action("hyper_after_nav");
?>