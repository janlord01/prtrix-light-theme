<?php
get_header();
?>
<main id="main">
    <?php

    if ( have_posts() )
    {
        while ( have_posts() )
        {
            the_post();
            ?>
            <div class="block"><!--here we have the whole content of the page-->
                <?php if(is_page(600)):?>
                <div id="privacy-title"> <!--the title we wrote in the wordpress page-->
                    <?php the_title("<h1>", "</h1>"); ?>
                </div>
                <?php endif; ?>
                <div class="page-body">
                    <?php
                    if ( has_post_thumbnail() )//if we added a thumbnail for that page
                    {
                        ?>
                        <div class="page-thumbnail">
                            <?php
                            the_post_thumbnail( 'medium', array( 'class'  => 'img-fluid' ) );
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="content-page"><!--The whole content we added-->
                        <?php the_content( ); ?>
                    </div>
                </div>
            </div>
            <?php
        } // end while
    } // end if
    ?>
</main>
<?php

get_footer();
