<?php

//AVOID CATEGORY
//EXCERPT LENGTH
//HEAD
//STYLES-SCRIPTS
//THEME SUPPORT
//SVG



/*******************************AVOID CATEGORY**************************************/
/* function wht_avoid_category_blog($avoid_category){
    $avoid_category = 6;

    return $avoid_category;
}
add_filter( 'avoid_category',  'wht_avoid_category_blog'); */


/*******************************EXCERPT LENGTH**************************************/
function wht_excerpt_length($length){
    return 80;
}
add_filter('excerpt_length', 'wht_excerpt_length');

/*******************************HEAD**************************************/
function wht_head(){
    
    ?>
<script async src="<?php echo get_template_directory_uri() . '/scripts/general.js'; ?>"></script>
<?php
}
add_action("wp_head", "wht_head");

/*******************************STYLES-SCRIPTS**************************************/
function wht_files() {
    //Styles
    wp_enqueue_style( 'achadata-style', get_stylesheet_uri() );

    if(is_front_page()){
        wp_enqueue_style( 'achadata-home', get_template_directory_uri() . '/styles/home.css' );
    }

    if(is_home()){
        wp_enqueue_style( 'achadata-blog', get_template_directory_uri() . '/styles/blog.css' );
    }

    if(is_single()){
        wp_enqueue_style( 'achadata-single', get_template_directory_uri() . '/styles/single.css' );
    }

    if(is_page()){
        wp_enqueue_style( 'achadata-page', get_template_directory_uri() . '/styles/page.css' );
    }

    if(is_author()){
        wp_enqueue_style( 'achadata-author', get_template_directory_uri() . '/styles/author.css' );
    }

    //jQuery
    wp_enqueue_script( 'jquery' );
} 
add_action( 'wp_enqueue_scripts', 'wht_files' );

/*******************************THEME SUPPORT**************************************/
function wht_the_support(){
    add_theme_support('post-thumbnails');
    add_theme_support('menus');
    add_theme_support('widgets');
    add_theme_support('title-tag');
    add_theme_support('custom-logo', array(
        'flex-height' => true
        ));
}
add_action('after_setup_theme', 'wht_the_support');

function wht_widgets(){
    register_sidebar( array(
        'name' => __( 'Footer Left' ),
        'id' => 'footer-left',
        'before_widget' => '',
        'after_widget'  => ''
    ));

    register_sidebar( array(
        'name' => __( 'Footer Center' ),
        'id' => 'footer-center',
        'before_widget' => '',
        'after_widget'  => ''
    ));

    register_sidebar( array(
        'name' => __( 'Footer Right' ),
        'id' => 'footer-right',
        'before_widget' => '',
        'after_widget'  => ''
    ));
}
add_action( 'widgets_init', 'wht_widgets' );

/*******************************SVG**************************************/
function wht_svg($data, $file, $filename, $mimes) {
    $tipo = wp_check_filetype( $filename, $mimes );
    return [
        'ext'             => $tipo['ext'],
        'type'            => $tipo['type'],
        'proper_filename' => $data['proper_filename']
    ];
};
add_filter( "wp_check_filetype_and_ext", "wht_svg", 10, 4);

function wht_tipos( $mimes ){
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'wht_tipos' );


/**
 * Disabled by Garry in May 27, 2024
 */

/*******************************achadata UPDATER**************************************/
//https://gist.github.com/slfrsn/a75b2b9ef7074e22ce3b
// function whupdates_check() {
// 	if ( is_admin() ) {
// 		include_once (get_template_directory() . '/../class/wh_updater.php');
// 		$config  = array(
// 			'github_uri' => 'https://api.github.com/repos/AlvaroAcha/wh_theme/releases',
// 			'token'      => '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',
// 		);
// 		$updater = new Whupdates_Updater( $config, __FILE__ );
// 		$updater->fgr_check_update();
// 	}
// }

//whupdates_check();

// From Child Theme


function exclude_category_home( $query ) {
	if ( $query->is_home ) {
		$query->set( 'cat', '-4' );
	}
	return $query;
}
add_filter( 'pre_get_posts', 'exclude_category_home' );

function hyper_analysis_scripts(){
    ?>
<script>
jQuery(document).ready(function() {

    jQuery(".toacha").each(function() {
        jQuery(this).on('click', function() {
            let clase = jQuery(this).attr("class");
            let loc = clase.indexOf("acha-");
            let whe = clase.substr(loc + 5, 3);

            let location = '';
            switch (whe) {
                case 'top':
                    location = 'top';
                    break;
                case 'bot':
                    location = 'bottom';
                    break;
                case 'cen':
                    location = 'center';
                    break;
                case 'lin':
                    location = 'link';
                    break;
                case 'foo':
                    location = 'footer';
                    break;
                case 'tit':
                    location = 'title';
                    break;
                case 'img':
                    location = 'image';
                    break;
            }

            gtag('event',
            'going_acha', { //going_acha needs to be defined in events/create event
                //'send_to': 'G-7VERBKWWZ6', //Looks like this is needed just when a group is added
                'location_item': location //This needs to be defined in custom definitions
            })
        })
    })
})
</script>
<?php
}
add_action("wp_footer", "hyper_analysis_scripts");