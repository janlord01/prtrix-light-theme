<?php
do_action("hyper_before_footer");
?>

<div id="top-footer-box">

    <div id="top-footer">
        <div>
            <img loading="lazy" width="60" height="60"
                src="<?php echo get_template_directory_uri() ?>/images/Free-Domestic-Shipping-for-Orders-Over-150.png"
                alt="Delivery Truck">
            <p>
                Free Domestic Shipping for Orders Over $150
            </p>
        </div>
        <div>
            <img loading="lazy" width="60" height="60"
                src="<?php echo get_template_directory_uri() ?>/images/30-Day-Money-Back-Guarantee.png"
                alt="Money Back">
            <p>
                30-Day Money-Back Guarantee
            </p>
        </div>
        <div>
            <img loading="lazy" width="60" height="60"
                src="<?php echo get_template_directory_uri() ?>/images/No-Minimum-Order-Quantity-for-Products.png"
                alt="No Minimum Order">
            <p>
                No Minimum Order Quantity for Products
            </p>
        </div>
        <div>
            <img loading="lazy" width="60" height="60"
                src="<?php echo get_template_directory_uri() ?>/images/10000-products-in-stock.png" alt="Fast Orders">
            <p>
                10,000+ products in stock
            </p>
        </div>
    </div>
</div>

<div class="site-footer">
    <footer>
        <div id="widgets-footer">
            <div id="widget-left">
                <?php if(! function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Left')) {} ?>
            </div>

            <div id="widget-center">
                <?php if(! function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Center')) {} ?>
            </div>

            <div id="widget-right">
                <?php if(! function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Right')) {} ?>
            </div>
        </div>
        <!-- <div id="credit_footer">
            <?php echo get_bloginfo(); ?> Copyright &copy; <?php echo get_the_date('Y'); ?>
        </div> -->
</div>
</footer>
</div>

<?php wp_footer(); ?>
</body>

</html>