<?php
get_header();
?>
<main id="main">
    <div class="content-page"><!--here we have the whole content of the page-->
    <?php

    if ( have_posts() )
    {
        while ( have_posts() )
        {
            the_post();
            
            $category = get_the_category(); 
            $avoid_category = 5;

            if ( has_filter( 'avoid_category' ) ) {
                $avoid_category = apply_filters( 'avoid_category', $avoid_category );
            }

            if($category[0]->term_id == $avoid_category){
                continue;
            }
            ?>
            <div class="article">
                <div class="page-thumbnail">
                    <a href="<?php the_permalink(); ?>">
                    <?php
                    the_post_thumbnail( 'thumbnail', array( 'class'  => 'img-fluid' ) );
                    ?>
                    </a>
                </div>
                <div class="page-body">
                    <div id="post-title"> <!--the title we wrote in the wordpress page-->
                        <a href="<?php the_permalink(); ?>">
                        <?php the_title("<h2>", "</h2>"); ?>
                        </a>
                    </div>
                    <div class="excerpt"><!--The whole content we added-->
                        <?php the_excerpt( ); ?>
                        <a href="<?php the_permalink(); ?>">
                            Ver más
                        </a>
                    </div>
                </div>
        </div>
            <?php
        } // end while
		the_posts_pagination(array(
			'mid-size' => 1
		));
    } // end if
    ?>
    </div>
</main>
<?php

get_footer();
